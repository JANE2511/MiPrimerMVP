from django.contrib import admin

from familia.models import *

admin.site.register(Persona)
